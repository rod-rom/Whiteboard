package com.example.project;

public class CourseResult {
    private String _id;
    private String courseName;
    private int courseNumber;
    private String[] assignments;

    public String get_id() {
        return _id;
    }

    public String getCourseName() {
        return courseName;
    }

    public int getCourseNumber() {
        return courseNumber;
    }

    public String[] getAssignments() {
        return assignments;
    }
}
