package com.example.project;

public class NotificationResult {
    private int courseNumber;
    private String courseId;
    private String content;

    public int getCourseNumber() {
        return courseNumber;
    }

    public String getCourseId() {
        return courseId;
    }

    public String getContent() {
        return content;
    }
}